#pragma once

#include <atomic>
#include <limits>
#include <memory>

#include <rclcpp/rclcpp.hpp>
#include <rviz_common/tool.hpp>
#include <rviz_common/viewport_mouse_event.hpp>

#include "iros_llm_swarm_interfaces/srv/list_obstacles.hpp"
#include "iros_llm_swarm_interfaces/srv/open_door.hpp"
#include "iros_llm_swarm_interfaces/srv/close_door.hpp"

namespace iros_llm_rviz_tool
{

class DoorTool : public rviz_common::Tool
{
  Q_OBJECT

public:
  using ListObstacles = iros_llm_swarm_interfaces::srv::ListObstacles;
  using OpenDoor      = iros_llm_swarm_interfaces::srv::OpenDoor;
  using CloseDoor     = iros_llm_swarm_interfaces::srv::CloseDoor;

  DoorTool();
  ~DoorTool() override = default;

  void onInitialize() override;
  void activate() override {}
  void deactivate() override {}
  int  processMouseEvent(rviz_common::ViewportMouseEvent & event) override;

private:
  bool getGroundPosition(rviz_common::ViewportMouseEvent & event, double & wx, double & wy);

  rclcpp::Node::SharedPtr node_;

  rclcpp::Client<ListObstacles>::SharedPtr list_client_;
  rclcpp::Client<OpenDoor>::SharedPtr      open_client_;
  rclcpp::Client<CloseDoor>::SharedPtr     close_client_;

  std::atomic<bool> pending_{false};
};

}  // namespace iros_llm_rviz_tool

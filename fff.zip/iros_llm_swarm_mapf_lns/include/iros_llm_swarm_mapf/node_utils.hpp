// iros_llm_swarm_mapf/node_utils.hpp
//
// ROS-side utilities for mapf_lns2_node. Pure functions: no shared mutable
// state and no logging side-effects (the optional logger argument lets the
// caller route diagnostics through its own rclcpp logger).

#pragma once

#include <cstddef>
#include <cstdint>
#include <utility>
#include <vector>

#include "rclcpp/logger.hpp"
#include "geometry_msgs/msg/point.hpp"
#include "iros_llm_swarm_interfaces/msg/mapf_step.hpp"

#include "iros_llm_swarm_mapf/lns2/types.hpp"

namespace lns2_node {

using MAPFStepMsg = iros_llm_swarm_interfaces::msg::MAPFStep;

// World <-> grid conversion. Coordinates clamp to the grid extent, matching
// the original node behaviour.
lns2::Cell world_to_cell(double wx, double wy,
                         double origin_x, double origin_y,
                         double resolution,
                         std::size_t rows, std::size_t cols);

void cell_to_world(const lns2::Cell& c,
                   double origin_x, double origin_y,
                   double resolution,
                   double& wx, double& wy);

// Compress a grid path into an ordered list of MAPFSteps. Consecutive
// entries at the same cell become a single step whose hold_sec counts the
// extra time beyond the arrival step (run length minus one, multiplied by
// time_step_sec).
std::vector<MAPFStepMsg> grid_path_to_steps(
    const lns2::Path& path,
    double origin_x, double origin_y, double resolution,
    double time_step_sec);

// Block grid cells occupied by robots that have arrived at their goal —
// active replans treat them as static obstacles. Uses physical footprint
// only (no inflation); the active robot's own footprint+inflation provides
// the safety buffer.
void block_arrived_robots(
    lns2::GridMap& grid,
    const std::vector<uint32_t>& arrived_ids,
    const std::vector<std::pair<double, double>>& positions,
    const std::vector<double>& fp_radii,
    double default_robot_radius,
    double origin_x, double origin_y, double resolution,
    int num_robots);

// Block grid cells occupied by robots that have odom but are NOT in the
// plan (e.g. skipped due to blocked goal). `logger` (optional) is used for
// the same diagnostics the original method emitted.
void block_skipped_robots(
    lns2::GridMap& grid,
    const std::vector<uint32_t>& planned_ext_ids,
    const std::vector<std::pair<double, double>>& positions,
    const std::vector<bool>& have_odom,
    const std::vector<double>& fp_radii,
    double default_robot_radius,
    double origin_x, double origin_y, double resolution,
    int num_robots,
    const rclcpp::Logger* logger = nullptr);

}  // namespace lns2_node

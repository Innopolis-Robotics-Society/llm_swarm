// iros_llm_swarm_mapf/plan_publisher.hpp
//
// Owns the per-robot MAPFPlan / cmd_vel publishers and the plan_id counter.
// All public methods must be called with the node's state mutex held — they
// touch shared `active_plan_id_` and the plan_id stream that check_schedule
// consumes via the same mutex.

#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"

#include "iros_llm_swarm_interfaces/msg/mapf_plan.hpp"

#include "iros_llm_swarm_mapf/lns2/types.hpp"

namespace lns2_node {

class PlanPublisher {
 public:
  using MAPFPlanMsg = iros_llm_swarm_interfaces::msg::MAPFPlan;

  // Create publishers for `num_robots` robots on `node`.
  void init(rclcpp::Node* node, int num_robots);

  int num_robots() const { return static_cast<int>(plan_pubs_.size()); }

  // Most recently committed plan_id (matches active_plan_id_ in the
  // pre-refactor node).
  std::uint32_t active_plan_id() const { return active_plan_id_; }

  struct PublishStats {
    std::uint32_t plan_id   = 0;
    std::size_t   published = 0;
    std::size_t   cancelled = 0;
  };

  // Publish a freshly-solved batch of MAPFPlans. Bumps plan_id_counter_
  // and stores the new plan_id as active_plan_id_. Stub paths (length 1)
  // and empty paths are published as empty plans (followers cancel).
  PublishStats publish_mapf_plans(
      const std::vector<lns2::Path>& paths,
      const std::vector<std::uint32_t>& plan_ids_ext,
      double origin_x, double origin_y, double resolution,
      double time_step_sec,
      const rclcpp::Time& stamp);

  // Send an empty MAPFPlan + zero Twist to every robot in `active_robot_ids`.
  // Used by handle_cancel for emergency stop.
  void publish_stop_all(const std::vector<std::uint32_t>& active_robot_ids,
                        const rclcpp::Time& stamp);

  // Send an empty MAPFPlan to a single robot — used to cancel the follower
  // for a benched / permanently-unplanable robot.
  void publish_cancel_for(std::uint32_t rid, const rclcpp::Time& stamp);

 private:
  std::uint32_t plan_id_counter_ = 0;
  std::uint32_t active_plan_id_  = 0;
  std::vector<rclcpp::Publisher<MAPFPlanMsg>::SharedPtr> plan_pubs_;
  std::vector<rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr> cmd_vel_pubs_;
};

}  // namespace lns2_node

#pragma once

#include "iros_llm_swarm_mapf/mapf_types.hpp"

#include <deque>
#include <queue>
#include <unordered_map>
#include <vector>

// ---------------------------------------------------------------------------
// ReservationTable
// ---------------------------------------------------------------------------
// Stores centres and radii of higher-priority agents.
// Conflict check via Euclidean distance between centres:
// if distance < (r_a + r_b), agents are considered in conflict.
// With zero radii the behaviour is identical to point-based checking.

class ReservationTable {
 public:
  void clear() {
    entries_.clear();
    held_goals_.clear();
  }

  // Reserve agent path with the given radius (in cells).
  // footprint_cells: physical (hard) radius in cells.
  // soft_radius_cells: footprint + inflation in cells (outer penalty boundary).
  // skip_until: don't reserve entries for t < skip_until (grace period
  // for agents whose starts overlap — lets them separate first).
  void reserve_path(const Path& path,
                    size_t hold_goal_until_time,
                    float footprint_cells, float soft_radius_cells,
                    size_t skip_until = 0) {
    if (path.empty()) return;
    for (size_t t = skip_until; t < path.size(); ++t) {
      entries_[t].push_back({path[t], footprint_cells, soft_radius_cells});
    }
    // Goal hold: agent stays in place after arrival
    if (path.size() <= hold_goal_until_time) {
      held_goals_.push_back({path.back(), footprint_cells, soft_radius_cells,
                             std::max(path.size(), skip_until)});
    }
  }

  // Gradient penalty for placing an agent at (row,col) at time t.
  // Returns: 0 = free, >0 = soft penalty, -1 = FORBIDDEN (physical overlap).
  // my_footprint/my_soft: agent's own radii in cells.
  // max_penalty: cost at the hard boundary (decreasing to 0 at soft boundary).
  // Multiple nearby agents: takes the greatest penalty, not sum.
  int vertex_penalty(size_t row, size_t col, size_t time,
                     float my_footprint, float my_soft,
                     int max_penalty = 50,
                     CostCurve cost_curve = CostCurve::Quadratic) const {
    int total = 0;
    auto check = [&](const Cell& c, float fp, float sr) {
      const float dr = static_cast<float>(row) - static_cast<float>(c.row);
      const float dc = static_cast<float>(col) - static_cast<float>(c.col);
      const float dist_sq = dr * dr + dc * dc;
      const float hard = my_footprint + fp;
      const float soft = my_soft + sr;
      if (hard > 0.0f && dist_sq < hard * hard) { total = -1; return; }
      if (soft > 0.0f && dist_sq < soft * soft) {
        const float dist = std::sqrt(dist_sq);
        const float ratio = (soft - dist) / (soft - hard);
        const int cost = static_cast<int>(
            apply_curve(ratio, cost_curve) * max_penalty);
        total = std::max(total, cost);
      }
    };

    // Check held goals
    for (const auto& hg : held_goals_) {
      if (time >= hg.from_time) {
        check(hg.cell, hg.footprint_cells, hg.soft_radius_cells);
        if (total < 0) return -1;
      }
    }
    // Check positions at the specific timestep
    auto it = entries_.find(time);
    if (it != entries_.end()) {
      for (const auto& e : it->second) {
        check(e.cell, e.footprint_cells, e.soft_radius_cells);
        if (total < 0) return -1;
      }
    }
    return total;
  }

  // Edge conflict: checks opposing movement between steps time and time+1.
  // Uses footprint (hard) radius only — physical swap prevention.
  bool is_edge_blocked(size_t fr, size_t fc, size_t tr, size_t tc,
                        size_t time, float my_footprint_cells) const {
    auto it = entries_.find(time);
    auto it_next = entries_.find(time + 1);
    if (it == entries_.end() || it_next == entries_.end()) return false;

    // For each agent: check if it moves in the opposite direction.
    // NOTE: pairing by vector index assumes reserve_path() is called
    // once per agent in a fixed order.  With skip_until, an agent's
    // entries start later, so indices at the grace boundary may differ —
    // the min(size, size) guard safely skips unmatched trailing entries.
    // TODO: edge conflicts are silently missed at the grace boundary
    // timestep. Fix by pairing entries by agent ID, not vector index.
    for (size_t i = 0; i < it->second.size() && i < it_next->second.size(); ++i) {
      const auto& cur  = it->second[i];
      const auto& next = it_next->second[i];
      // Edge conflict: after swap both agents end up too close
      // to each other's previous position
      if (cells_conflict(fr, fc, my_footprint_cells,
                          next.cell.row, next.cell.col, cur.footprint_cells) &&
          cells_conflict(tr, tc, my_footprint_cells,
                          cur.cell.row, cur.cell.col, cur.footprint_cells))
        return true;
    }
    return false;
  }

  // Can the agent hold its goal starting from from_time?
  // Uses footprint (hard) radius — agent can hold goal as long as no
  // physical overlap with other agents' paths or held goals.
  bool can_hold_goal(size_t row, size_t col, size_t from_time,
                      size_t max_time, float my_footprint_cells) const {
    for (const auto& hg : held_goals_) {
      if (cells_conflict(row, col, my_footprint_cells,
                          hg.cell.row, hg.cell.col, hg.footprint_cells))
        return false;
    }
    for (size_t t = from_time; t <= max_time; ++t) {
      auto it = entries_.find(t);
      if (it == entries_.end()) continue;
      for (const auto& e : it->second) {
        if (cells_conflict(row, col, my_footprint_cells,
                            e.cell.row, e.cell.col, e.footprint_cells))
          return false;
      }
    }
    return true;
  }

 private:
  struct Entry {
    Cell cell;
    float footprint_cells;    // physical (hard) radius in cells
    float soft_radius_cells;  // footprint + inflation in cells
  };
  struct HeldGoal {
    Cell cell;
    float footprint_cells;
    float soft_radius_cells;
    size_t from_time;
  };

  std::unordered_map<size_t, std::vector<Entry>> entries_;  // time -> entries
  std::vector<HeldGoal> held_goals_;

  // Two-circle conflict check: distance between centres < sum of radii.
  // With zero radii — point-based cell coincidence check.
  static bool cells_conflict(size_t r1, size_t c1, float rad1,
                              size_t r2, size_t c2, float rad2) {
    const float min_dist = rad1 + rad2;
    if (min_dist <= 0.0f) {
      return r1 == r2 && c1 == c2;
    }
    const float dr = static_cast<float>(r1) - static_cast<float>(r2);
    const float dc = static_cast<float>(c1) - static_cast<float>(c2);
    return dr * dr + dc * dc < min_dist * min_dist;
  }
};

// ---------------------------------------------------------------------------
// Space-Time A*
// ---------------------------------------------------------------------------

class SpaceTimeAStarPlanner {
 public:
  SpaceTimeAStarPlanner() = default;

  void reset_map(const GridMap* map) { map_ = map; }
  const GridMap* current_map() const { return map_; }
  void set_goal_dists(const std::vector<int>* d) { goal_dists_ = d; }
  size_t last_expansions() const { return last_expansions_; }

  // my_footprint_cells — physical (hard) radius of this agent in cells.
  // my_soft_cells — footprint + inflation in cells (outer penalty boundary).
  // cost_curve — gradient shape (Linear, Quadratic, Cubic).
  // proximity_penalty — cost per step at the hard boundary.
  // max_astar_expansions — per-call expansion limit (0 = unlimited).
  bool find_path(const Cell& start, const Cell& goal,
                 const ReservationTable& reservations,
                 float my_footprint_cells, float my_soft_cells,
                 size_t max_time, Path& path,
                 CostCurve cost_curve = CostCurve::Quadratic,
                 int proximity_penalty = 50,
                 size_t max_astar_expansions = 0) {
    my_footprint_ = my_footprint_cells;
    my_soft_ = my_soft_cells;
    cost_curve_ = cost_curve;
    proximity_penalty_ = proximity_penalty;

    path.clear();
    if (!map_) return false;
    if (is_blocked(start.row, start.col) || is_blocked(goal.row, goal.col)) return false;

    const size_t spatial = map_->rows * map_->cols;
    const size_t state_count = spatial * (max_time + 1);

    ensure_capacity(state_count);
    next_generation();

    const size_t start_idx = idx(start.row, start.col);
    const size_t goal_idx  = idx(goal.row, goal.col);
    const size_t start_state = state_idx(start_idx, 0, spatial);

    // NOTE: we intentionally do NOT reject starts that overlap with
    // reservations at t=0.  During replanning agents are physically at
    // their current positions and must be allowed to start there even if
    // another agent's reservation covers the same cell.  A* will
    // naturally find a path that diverges at t=1+.

    set_g(start_state, 0);
    parent_[start_state] = INVALID;

    std::priority_queue<Node, std::vector<Node>, NodeCmp> open;
    open.push({start_idx, 0, 0, heuristic(start, goal)});

    last_expansions_ = 0;
    while (!open.empty()) {
      ++last_expansions_;
      if (max_astar_expansions > 0 && last_expansions_ > max_astar_expansions)
        return false;

      const Node cur = open.top(); open.pop();
      const size_t cs = state_idx(cur.idx, cur.t, spatial);

      if (is_closed(cs)) continue;
      if (!is_alive(cs) || cur.g != g_[cs]) continue;
      mark_closed(cs);

      if (cur.idx == goal_idx) {
        if (reservations.can_hold_goal(goal.row, goal.col, cur.t,
                                        max_time, my_footprint_cells)) {
          restore(cs, spatial, path);
          return true;
        }
      }

      if (cur.t >= max_time) continue;

      const Cell c  = cell(cur.idx);
      const size_t r = c.row, col_ = c.col;
      const size_t nt = cur.t + 1;

      // wait in place
      relax(cur.idx, cur.t, r, col_, nt, goal, reservations, open, spatial);
      // neighbours
      if (r > 0)               relax(cur.idx, cur.t, r-1, col_,   nt, goal, reservations, open, spatial);
      if (r+1 < map_->rows)    relax(cur.idx, cur.t, r+1, col_,   nt, goal, reservations, open, spatial);
      if (col_ > 0)            relax(cur.idx, cur.t, r,   col_-1, nt, goal, reservations, open, spatial);
      if (col_+1 < map_->cols) relax(cur.idx, cur.t, r,   col_+1, nt, goal, reservations, open, spatial);
    }
    return false;
  }

 private:
  static constexpr int    INF     = std::numeric_limits<int>::max() / 4;
  static constexpr size_t INVALID = std::numeric_limits<size_t>::max();

  struct Node { size_t idx, t; int g, f; };
  struct NodeCmp {
    bool operator()(const Node& a, const Node& b) const {
      return a.f != b.f ? a.f > b.f : a.g < b.g;
    }
  };

  const GridMap*  map_           = nullptr;
  const std::vector<int>* goal_dists_ = nullptr;  // precomputed Dijkstra from goal
  float           my_footprint_  = 0.0f;   // current agent's hard radius in cells
  float           my_soft_       = 0.0f;   // current agent's soft radius in cells
  CostCurve       cost_curve_    = CostCurve::Quadratic;
  int             proximity_penalty_ = 50; // cost at hard boundary
  size_t          last_expansions_ = 0;    // expansions in last find_path call
  std::vector<int>      g_;
  std::vector<size_t>   parent_;
  std::vector<uint8_t>  closed_;
  std::vector<uint32_t> gen_;
  uint32_t current_gen_ = 1;

  size_t idx(size_t r, size_t c) const { return r * map_->cols + c; }
  Cell   cell(size_t i)          const { return {i / map_->cols, i % map_->cols}; }

  static size_t state_idx(size_t ci, size_t t, size_t sp) { return t * sp + ci; }
  static size_t state_cell(size_t si, size_t sp)           { return si % sp; }

  bool is_blocked(size_t r, size_t c) const { return map_->blocked[idx(r,c)] != 0; }

  int wall_penalty(size_t r, size_t c) const {
    return map_->wall_cost.empty() ? 0 : map_->wall_cost[idx(r,c)];
  }

  // Heuristic for A*: precomputed Dijkstra step-distance from goal.
  // Accounts for wall topology (blocked cells) but excludes penalties.
  // Admissible — always <= true cost.  Falls back to Manhattan if
  // goal_dists_ is not set (e.g. during testing).
  int heuristic(const Cell& a, const Cell& b) const {
    if (goal_dists_) {
      const int d = (*goal_dists_)[idx(a.row, a.col)];
      return d < INF ? d : INF;
    }
    const int dr = a.row > b.row ? a.row - b.row : b.row - a.row;
    const int dc = a.col > b.col ? a.col - b.col : b.col - a.col;
    return dr + dc;
  }

  void ensure_capacity(size_t n) {
    if (g_.size() >= n) return;
    g_.resize(n, INF); parent_.resize(n, INVALID);
    closed_.resize(n, 0); gen_.resize(n, 0);
  }

  void next_generation() {
    if (++current_gen_ == 0) { current_gen_ = 1; std::fill(gen_.begin(), gen_.end(), 0); }
  }

  bool   is_alive(size_t s)  const { return gen_[s] == current_gen_; }
  int    get_g(size_t s)     const { return is_alive(s) ? g_[s] : INF; }
  void   set_g(size_t s, int v)    { gen_[s] = current_gen_; g_[s] = v; closed_[s] = 0; }
  bool   is_closed(size_t s) const { return is_alive(s) && closed_[s]; }
  void   mark_closed(size_t s)     { closed_[s] = 1; }

  void relax(size_t ci, size_t ct, size_t nr, size_t nc, size_t nt,
             const Cell& goal, const ReservationTable& res,
             std::priority_queue<Node, std::vector<Node>, NodeCmp>& open,
             size_t sp) {
    if (is_blocked(nr, nc)) return;

    const size_t ni = idx(nr, nc);
    const bool moving = (ni != ci);

    // Wall penalty only when entering a new cell (not waiting).
    // Agent penalty every timestep (occupying space near them).
    int penalty = moving ? wall_penalty(nr, nc) : 0;

    const int agent_pen = res.vertex_penalty(
        nr, nc, nt, my_footprint_, my_soft_,
        proximity_penalty_, cost_curve_);
    if (agent_pen < 0) return;  // physical agent overlap forbidden
    penalty += agent_pen;

    // Edge conflict: check opposing movement (uses footprint/hard radius)
    const Cell from_cell = cell(ci);
    if (res.is_edge_blocked(from_cell.row, from_cell.col, nr, nc, ct, my_footprint_))
      return;

    const size_t cs = state_idx(ci, ct, sp);
    const size_t ns = state_idx(ni, nt, sp);
    if (is_closed(ns)) return;

    // Every timestep costs 1.  Movement adds 1 more — agents prefer
    // waiting over unnecessary walking.
    const int tg = get_g(cs) + 1 + (moving ? 1 : 0) + penalty;
    if (tg < get_g(ns)) {
      set_g(ns, tg);
      parent_[ns] = cs;
      open.push({ni, nt, tg, tg + heuristic({nr, nc}, goal)});
    }
  }

  void restore(size_t goal_state, size_t sp, Path& path) const {
    for (size_t cur = goal_state; cur != INVALID; cur = parent_[cur])
      path.push_back(cell(state_cell(cur, sp)));
    std::reverse(path.begin(), path.end());
  }
};
